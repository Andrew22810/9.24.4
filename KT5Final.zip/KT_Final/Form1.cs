using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace KT_Final
{
    public partial class Form1 : Form
    {
        private string _connectionString;

        // === Контролы ===
        private Label lblId;
        private TextBox tbId;

        private Label lblName;
        private TextBox tbName;

        private Label lblEmail;
        private TextBox tbEmail;

        private Button btnInsert;
        private Button btnLoad;

        private Label lblData;

        public Form1()
        {
            InitializeComponent();
            this.Load += Form1_Load;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            _connectionString =
                ConfigurationManager.ConnectionStrings["MyConnectionString"].ConnectionString;

            CreateControls();
        }

        private void CreateControls()
        {
            this.Text = "Работа с БД";
            this.Size = new Size(500, 550);

            // ID
            lblId = new Label()
            {
                Text = "ID:",
                Location = new Point(20, 20),
                AutoSize = true
            };

            tbId = new TextBox()
            {
                Location = new Point(120, 20),
                Width = 200
            };

            // Name
            lblName = new Label()
            {
                Text = "Имя:",
                Location = new Point(20, 60),
                AutoSize = true
            };

            tbName = new TextBox()
            {
                Location = new Point(120, 60),
                Width = 200
            };

            // Email
            lblEmail = new Label()
            {
                Text = "Email:",
                Location = new Point(20, 100),
                AutoSize = true
            };

            tbEmail = new TextBox()
            {
                Location = new Point(120, 100),
                Width = 200
            };

            // Insert Button
            btnInsert = new Button()
            {
                Text = "Добавить",
                Location = new Point(120, 140),
                Width = 200
            };
            btnInsert.Click += InsertData;

            // Load Button
            btnLoad = new Button()
            {
                Text = "Загрузить данные",
                Location = new Point(120, 180),
                Width = 200
            };
            btnLoad.Click += LoadData;

            // Data Label
            lblData = new Label()
            {
                Location = new Point(20, 230),
                Size = new Size(440, 250),
                BorderStyle = BorderStyle.FixedSingle
            };

            // Добавление на форму
            this.Controls.AddRange(new Control[]
            {
                lblId, tbId,
                lblName, tbName,
                lblEmail, tbEmail,
                btnInsert, btnLoad,
                lblData
            });
        }

        // === Добавление данных ===
        private void InsertData(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                string sql = @"
                    INSERT INTO MyTable1 (Id, Name, Email)
                    VALUES (@Id, @Name, @Email)";

                using (SqlCommand cmd = new SqlCommand(sql, connection))
                {
                    cmd.Parameters.AddWithValue("@Id", Convert.ToInt32(tbId.Text));
                    cmd.Parameters.AddWithValue("@Name", tbName.Text);
                    cmd.Parameters.AddWithValue("@Email", tbEmail.Text);

                    cmd.ExecuteNonQuery();
                }
            }

            MessageBox.Show("Данные добавлены");
            tbName.Clear();
            tbEmail.Clear();
        }

        // === Чтение данных ===
        private void LoadData(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                string sql = "SELECT Id, Name, Email FROM MyTable1";

                using (SqlCommand cmd = new SqlCommand(sql, connection))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    StringBuilder sb = new StringBuilder();

                    while (reader.Read())
                    {
                        sb.AppendLine($"{reader["Id"]} | {reader["Name"]} | {reader["Email"]}");
                    }

                    lblData.Text = sb.ToString();
                }
            }
        }
    }
}